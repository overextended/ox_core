-- Temporary backwards compatibility, to be removed..
if not lib then return end

return require '@ox_core.lib.server.init'
