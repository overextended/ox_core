fx_version 'cerulean'
game 'gta5'

name '@overextended/ox_core'
author 'Overextended'
version '0.19.0'
license 'LGPL-3.0-or-later'
repository 'https://github.com/overextended/ox_core.git'
description 'A modern FiveM framework.'

dependencies {
    '/server:7290',
    '/onesync',
}

files {
    'lib/init.lua',
    'lib/client/**.lua',
    'imports/client.lua',
    'locales/*.json',
    'common/data/*.json',
}

client_script 'dist/client.js'
server_script 'dist/server.js'

